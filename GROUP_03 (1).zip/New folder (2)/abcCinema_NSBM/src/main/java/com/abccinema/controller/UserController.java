package com.abccinema.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.abccinema.domain.User;
import com.abccinema.services.HashingService;
import com.abccinema.services.LoginService;
import com.google.gson.Gson;

/**
 * Servlet implementation class UserController
 */
@WebServlet(urlPatterns={"/login", "/logout", "/getUser", "/Register"})
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private  HashingService _hashingService;
    private LoginService _loginService;
    private Gson gson;
    
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserController() {
        this._hashingService = new HashingService();
        this._loginService = new LoginService();
        this.gson = new Gson();
        
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		switch (action) {
		case "/login":
			User loggedUser = this._loginService.login(request);
			System.out.println(loggedUser.getUsername());
			if(loggedUser.getUsername() != null) {
				HttpSession session = request.getSession(true);
				
				session.putValue("username",loggedUser.getUsername());
				session.putValue("userId",loggedUser.getUserId());
			}
			break;
			
		case "/getUser":
			PrintWriter out  = response.getWriter();
			try {
				HttpSession session = request.getSession(true);
				String user = (String)session.getValue("username");
				int userId = (Integer)session.getValue("userId");
				
				
				String usrJson = this.gson.toJson(new User(userId,user));
				

				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");

				out.print(usrJson);
				out.flush();
			
				
			}catch(NullPointerException e){
				response.setContentType("application/json");
				response.setCharacterEncoding("UTF-8");

				out.print(this.gson.toJson(new User(0,"Default")));
				out.flush();
			}
			
			break;
			
		case "/logout":
			HttpSession s = request.getSession(true);
			s.removeValue("username");
			s.removeValue("userId");
			break;
			
		case "/Register":
			try {
				this._loginService.registerUser(new User(0, request.getParameter("Username"), request.getParameter("Address"), request.getParameter("Password"), request.getParameter("Tp"), request.getParameter("Email")));
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
	
	 

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

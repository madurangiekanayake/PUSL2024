package com.abccinema.domain;

import java.time.LocalDateTime;
import java.util.List;

public class dtoScheduledMovies {
	private int MovieId;
	private String Movie;
	private int ShowTimeId;
	private String MovieDescription;
	private String Director;
	private List<Integer> ReservedSeats;
	private String ImagePath;

	private String StrShowTime;
	
	public dtoScheduledMovies(int movieId, String movie, int showTimeId, String strShowTime) {
		
		MovieId = movieId;
		Movie = movie;
		ShowTimeId = showTimeId;
		StrShowTime = strShowTime;
		
	}
	public String getImagePath() {
		return ImagePath;
	}
	public void setImagePath(String imagePath) {
		ImagePath = imagePath;
	}
	public String getStrShowTime() {
		return StrShowTime;
	}
	public void setStrShowTime(String strShowTime) {
		StrShowTime = strShowTime;
	}
	
	public int getMovieId() {
		return MovieId;
	}
	public void setMovieId(int movieId) {
		MovieId = movieId;
	}
	public String getMovie() {
		return Movie;
	}
	public void setMovie(String movie) {
		Movie = movie;
	}
	public int getShowTimeId() {
		return ShowTimeId;
	}
	public dtoScheduledMovies(int movieId, String movie, int showTimeId, String movieDescription, String director,
			String strShowTime, String imagePath) {
	
		MovieId = movieId;
		Movie = movie;
		ShowTimeId = showTimeId;
		MovieDescription = movieDescription;
		Director = director;
		StrShowTime = strShowTime;
		ImagePath = imagePath;
	}
	public dtoScheduledMovies(int movieId, String movie, int showTimeId, String movieDescription, String director,
			List<Integer> reservedSeats, String strShowTime) {
		super();
		MovieId = movieId;
		Movie = movie;
		ShowTimeId = showTimeId;
		MovieDescription = movieDescription;
		Director = director;
		ReservedSeats = reservedSeats;
		StrShowTime = strShowTime;
	}
	public String getMovieDescription() {
		return MovieDescription;
	}
	public void setMovieDescription(String movieDescription) {
		MovieDescription = movieDescription;
	}
	public String getDirector() {
		return Director;
	}
	public void setDirector(String director) {
		Director = director;
	}
	public List<Integer> getReservedSeats() {
		return ReservedSeats;
	}
	public void setReservedSeats(List<Integer> reservedSeats) {
		ReservedSeats = reservedSeats;
	}
	public void setShowTimeId(int showTimeId) {
		ShowTimeId = showTimeId;
	}

	
	
}

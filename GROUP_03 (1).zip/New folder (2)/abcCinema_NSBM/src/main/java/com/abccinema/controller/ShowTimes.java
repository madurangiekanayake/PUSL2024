package com.abccinema.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.abccinema.services.MovieTimeService;
import com.abccinema.services.ReservationService;
import com.google.gson.Gson;

/**
 * Servlet implementation class ShowTimes
 */
@WebServlet(urlPatterns={"/ShowTimes","/Review", "/ShowTimes/view", "/GetMoviesByUser"})
public class ShowTimes extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MovieTimeService movieTimeService;
	private Gson gson;
	private ReservationService _reservation;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowTimes() {
        super();
        movieTimeService = new MovieTimeService();
        this.gson = new Gson();
        this._reservation = new ReservationService();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);
		switch(action) {
			case "/ShowTimes/view":
				View(request, response);
				break;
			case "/GetMoviesByUser":
				this.GetReservationsByUserId(request, response);
				break;
			case "/Review":
				this._reservation.createReview(Integer.parseInt(request.getParameter("reservationId")), request.getParameter("review"));
				break;
		}
	}
	
	private void GetReservationsByUserId(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String usrJson = this.gson.toJson(movieTimeService.getReservationsByUserId(Integer.parseInt(request.getParameter("userID"))));
		
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
	
		out.print(usrJson);
		out.flush();
	}
	
	private void View(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("MovieTimes", movieTimeService.GetConfiguredDates());
		request.getRequestDispatcher("/views/ShowTimes.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}

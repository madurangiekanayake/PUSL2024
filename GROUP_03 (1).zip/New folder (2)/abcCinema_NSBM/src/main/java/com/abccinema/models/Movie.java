package com.abccinema.models;

public class Movie {
	public int id;
	public String MovieTitle;
	public String Description;
	public String ImagePath;
	public String Director;
	public int reservationId;
	public String reservationDate;
	public Movie(int id, String movieTitle, String description, String imagePath, String director, int reservationId) {
		super();
		this.id = id;
		MovieTitle = movieTitle;
		Description = description;
		ImagePath = imagePath;
		Director = director;
		this.reservationId = reservationId;
	}
	public Movie(int id, String movieTitle, String imagePath, int reservationId, String reservationDate) {
		super();
		this.id = id;
		MovieTitle = movieTitle;
		ImagePath = imagePath;
		this.reservationId = reservationId;
		this.reservationDate = reservationDate;
	}
	public int getReservationId() {
		return reservationId;
	}
	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMovieTitle() {
		return MovieTitle;
	}
	public void setMovieTitle(String movieTitle) {
		MovieTitle = movieTitle;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public String getImagePath() {
		return ImagePath;
	}
	public void setImagePath(String imagePath) {
		ImagePath = imagePath;
	}
	public String getDirector() {
		return Director;
	}
	public void setDirector(String director) {
		Director = director;
	}
	public Movie(int id, String movieTitle, String description, String imagePath, String director) {
		super();
		this.id = id;
		MovieTitle = movieTitle;
		Description = description;
		ImagePath = imagePath;
		Director = director;
	}
	public Movie(String movieTitle, String description, String imagePath, String director) {
		super();
		MovieTitle = movieTitle;
		Description = description;
		ImagePath = imagePath;
		Director = director;
	}
}

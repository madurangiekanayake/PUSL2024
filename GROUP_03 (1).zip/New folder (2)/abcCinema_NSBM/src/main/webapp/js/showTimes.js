

function activeDate(date){
	$.ajax({
           url: "/abcCinema_NSBM/MoviesByDatesController?dateSelected="+ date,
           dataType: "json",
           type: "GET",
           async: true,
           
           success: function (data) {
                   setMovieList(data);
					setActiveItemClass(date);

				 
           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
              
              
           }
       });
}

var clsList =[]

function setMovieList(data){
	var list = document.getElementById('movieList');
	
	
	var innerStr = "";
	for(var i =0; i < data.length; i++){
		var newCard = `<div class="col-6 mb-3"><button onclick="location.href='/abcCinema_NSBM/SeatIndex?timeId=`+data[i].ShowTimeId+`'" style="background: transparent; border: none !important; outline:none;"><div class="card mb-3" style="max-width: 540px;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="`+data[i].ImagePath +`.jpeg" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">` + data[i].Movie+`</h5>
        <p class="card-text">`+data[i].MovieDescription+`</p>
        <p class="card-text "><small class="text-muted">Directed by: `+data[i].Director+`</small></p>
		<p class="card-text text-danger "><small class="text-muted">Date and Time of the show: `+data[i].StrShowTime+`</small></p>
      </div>
    </div>
  </div>
</div></button></div>`;
		innerStr = innerStr + newCard;
		
	}
	list.innerHTML = innerStr;
};

function setActiveItemClass(id){
	var list = document.getElementById("dateList");
	var activeDates = list.getElementsByClassName("active");
	console.log(activeDates.length);
	for(var i = 0; i < activeDates.length; i++){
		activeDates[i].classList.remove("active");
	}
	
	var activeItem = document.getElementById(id);
	activeItem.classList.add("active");
	
}


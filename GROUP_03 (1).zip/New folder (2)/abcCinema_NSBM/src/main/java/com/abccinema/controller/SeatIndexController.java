package com.abccinema.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.abccinema.services.MovieTimeService;
import com.abccinema.services.ReservationService;
import com.abccinema.services.SendMail;
import com.google.gson.Gson;

/**
 * Servlet implementation class SeatIndexController
 */
@WebServlet(urlPatterns={"/SeatIndex", "/getReservedSeats", "/CreateReservation"} )
public class SeatIndexController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private Gson gson;
      private MovieTimeService _movieTimeService;
      private ReservationService _reservationService;
      private SendMail _mail;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SeatIndexController() {
        super();
        gson = new Gson();
        _movieTimeService = new MovieTimeService();
        _reservationService = new ReservationService();
        this._mail = new SendMail();
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		System.out.println(action);
		
		switch(action) {
		case "/getReservedSeats":
			getReservedSeats(request, response);
			break;
		case "/SeatIndex":
			View(request, response);
			break;
			
		
			
	}
		
			
		
		
		
	}
	
	private void getReservedSeats(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String usrJson = this.gson.toJson(_movieTimeService.getSeatsReserved(Integer.parseInt(request.getParameter("timeId"))));
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
	
		out.print(usrJson);
		out.flush();
	}
	private void View(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("MovieTim", request.getParameter("timeId"));
		request.getRequestDispatcher("views/PickSeats.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println(request.getParameter("FirstName"));
		_reservationService.reserveSeats(request);
		//this._mail.Post("");
		
		
		
	}

}

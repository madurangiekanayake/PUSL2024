-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: test1
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_seat_reservations`
--

DROP TABLE IF EXISTS `tbl_seat_reservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_seat_reservations` (
  `SeatId` int NOT NULL,
  `ReservationId` int NOT NULL,
  PRIMARY KEY (`SeatId`,`ReservationId`),
  KEY `Constr_tbl_seat_reservations_Reservation_fk` (`ReservationId`),
  CONSTRAINT `Constr_tbl_seat_reservations_Reservation_fk` FOREIGN KEY (`ReservationId`) REFERENCES `tblreservations` (`ReservationId`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Constr_tbl_seat_reservations_Seat_fk` FOREIGN KEY (`SeatId`) REFERENCES `tblseats` (`SeatId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_seat_reservations`
--

LOCK TABLES `tbl_seat_reservations` WRITE;
/*!40000 ALTER TABLE `tbl_seat_reservations` DISABLE KEYS */;
INSERT INTO `tbl_seat_reservations` VALUES (4,1),(5,1),(1,2),(2,2),(6,4),(9,37),(4,38),(10,38),(11,38),(12,39),(13,39);
/*!40000 ALTER TABLE `tbl_seat_reservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmovies`
--

DROP TABLE IF EXISTS `tblmovies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmovies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `MovieTitle` varchar(300) DEFAULT NULL,
  `Director` varchar(100) DEFAULT NULL,
  `Description` varchar(1000) DEFAULT NULL,
  `ImagePath` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmovies`
--

LOCK TABLES `tblmovies` WRITE;
/*!40000 ALTER TABLE `tblmovies` DISABLE KEYS */;
INSERT INTO `tblmovies` VALUES (1,'Avatar: The Way of Water','James Cameron','Jake Sully and Ney\'tiri have formed a family and are doing everything to stay together. However, they must leave their home and explore the regions of Pandora. When an ancient threat resurfaces, Jake must fight a difficult war against the humans.','/abcCinema_NSBM/Images/Thumbnails/Avatartmbnl'),(2,'Black Panther: Wakanda Forever','Ryan Coogler','Queen Ramonda, Shuri, M\'Baku, Okoye and the Dora Milaje fight to protect their nation from intervening world powers in the wake of King T\'Challa\'s death. As the Wakandans strive to embrace their next chapter, the heroes must band together with Nakia and Everett Ross to forge a new path for their beloved kingdom.','/abcCinema_NSBM/Images/Thumbnails/WakandaForeverthmbnl'),(3,'Avengers: Endgame','Anthony Russo, Joe Russo','After Thanos, an intergalactic warlord, disintegrates half of the universe, the Avengers must reunite and assemble again to reinvigorate their trounced allies and restore balance.','/abcCinema_NSBM/Images/Thumbnails/Endgametmbnl');
/*!40000 ALTER TABLE `tblmovies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmovietimes`
--

DROP TABLE IF EXISTS `tblmovietimes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmovietimes` (
  `MovieTimeId` int NOT NULL AUTO_INCREMENT,
  `DateAndTime` datetime DEFAULT NULL,
  `IsActive` tinyint(1) DEFAULT NULL,
  `tblmovieId` int DEFAULT NULL,
  PRIMARY KEY (`MovieTimeId`),
  KEY `FK_tblmovie_tblmovietimes` (`tblmovieId`),
  CONSTRAINT `FK_tblmovie_tblmovietimes` FOREIGN KEY (`tblmovieId`) REFERENCES `tblmovies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmovietimes`
--

LOCK TABLES `tblmovietimes` WRITE;
/*!40000 ALTER TABLE `tblmovietimes` DISABLE KEYS */;
INSERT INTO `tblmovietimes` VALUES (1,'2022-12-30 10:30:00',1,1),(2,'2022-12-30 13:30:00',1,2),(3,'2022-12-29 10:30:00',1,2),(4,'2022-12-29 13:30:00',1,3),(5,'2023-01-01 10:30:00',1,3),(6,'2023-01-01 13:30:00',1,2),(7,'2022-12-31 10:30:00',1,1),(8,'2023-01-05 10:30:00',1,3),(9,'2023-01-04 13:30:00',1,3);
/*!40000 ALTER TABLE `tblmovietimes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblreservations`
--

DROP TABLE IF EXISTS `tblreservations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblreservations` (
  `ReservationId` int NOT NULL AUTO_INCREMENT,
  `ReservedPerson` varchar(300) DEFAULT NULL,
  `CurrentDate` datetime DEFAULT NULL,
  `tblmovieId` int DEFAULT NULL,
  `tblmovietimeId` int DEFAULT NULL,
  `Address` varchar(400) DEFAULT NULL,
  `MobileNo` varchar(45) DEFAULT NULL,
  `FirstName` varchar(45) DEFAULT NULL,
  `LastName` varchar(45) DEFAULT NULL,
  `Guid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ReservationId`),
  KEY `FK_tblmovie` (`tblmovieId`),
  KEY `FK_tblmovietime_tblreservations` (`tblmovietimeId`),
  CONSTRAINT `FK_tblmovie` FOREIGN KEY (`tblmovieId`) REFERENCES `tblmovies` (`id`),
  CONSTRAINT `FK_tblmovietime_tblreservations` FOREIGN KEY (`tblmovietimeId`) REFERENCES `tblmovietimes` (`MovieTimeId`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblreservations`
--

LOCK TABLES `tblreservations` WRITE;
/*!40000 ALTER TABLE `tblreservations` DISABLE KEYS */;
INSERT INTO `tblreservations` VALUES (1,'Deshan','2022-12-27 00:00:00',1,1,NULL,NULL,NULL,NULL,NULL),(2,'Bob','2022-12-29 06:45:00',1,1,NULL,NULL,NULL,NULL,NULL),(3,'testtest','2023-01-01 19:58:34',NULL,1,'test','54354','testt','est',NULL),(4,'test2trst','2023-01-01 20:11:38',NULL,1,'test','231','test2','trst','cd815380-d7f3-44b6-88dc-baa5f83e247a'),(6,'','2023-01-01 20:43:14',NULL,1,'','','','','cf51f8e6-f5c2-47a0-8ffc-6d2665b820e6'),(7,'','2023-01-01 20:45:36',NULL,1,'','','','','99c708eb-d14d-4b54-b147-b4d3a07af880'),(8,'','2023-01-01 20:53:43',NULL,1,'','','','','838ef90a-9ace-4d08-b78e-88e4921c13a5'),(9,'','2023-01-01 20:55:12',NULL,1,'','','','','226cd24b-bde3-4015-bab9-46a6f4bc4b3d'),(10,'','2023-01-01 20:56:16',NULL,1,'','','','','0aaaead4-92b9-49e8-adb6-141a21733bbb'),(11,'','2023-01-01 20:56:39',NULL,1,'','','','','956ac187-e9c7-4bb5-9279-885e52df52f2'),(12,'','2023-01-01 20:57:25',NULL,1,'','','','','7f287bb3-4424-4e00-a5a1-0025e615e2c3'),(13,'','2023-01-01 20:59:05',NULL,1,'','','','','54a66082-404b-4749-9fc5-439882e1e15f'),(14,'','2023-01-01 21:05:33',NULL,1,'','','','','7da7c33c-5b96-46a0-8809-704500004d29'),(15,'','2023-01-01 21:12:59',NULL,1,'','','','','6b339e99-6269-4982-ac5e-bcbf8b8e64cc'),(16,'','2023-01-01 21:14:18',NULL,1,'','','','','b8f20abc-1849-49a8-a730-52b80157d8d4'),(17,'','2023-01-01 21:15:17',NULL,1,'','','','','91729647-b2d4-44b7-8691-fe191a827871'),(18,'','2023-01-01 21:16:18',NULL,1,'','','','','ec3faa54-3287-49e6-b132-ee04016d714c'),(19,'','2023-01-01 21:17:10',NULL,1,'','','','','608463da-6529-463a-b547-3ff297963f3e'),(20,'','2023-01-01 21:25:13',NULL,1,'','','','','30038614-ba17-4351-ad31-59a9e9be8fa1'),(21,'','2023-01-01 21:26:56',NULL,1,'','','','','6d09eeea-e13f-43b9-ad18-5eb58904e13b'),(22,'testtesttest','2023-01-01 21:30:02',NULL,5,'test','32','testtesttest','','876a8a14-638d-4e0c-a65d-07a7f629e196'),(23,'testtesttest','2023-01-01 21:32:08',NULL,5,'test','32','testtesttest','','a721c494-fd90-4301-a95a-191de4159ba3'),(24,'testtesttest','2023-01-01 21:33:13',NULL,5,'test','32','testtesttest','','55661058-e04d-4524-8cab-d4d259f4b774'),(25,'testtesttest','2023-01-01 21:48:48',NULL,5,'test','32','testtesttest','','9513666f-7721-4e0f-989a-f61205c29869'),(26,'testtesttest','2023-01-01 21:49:33',NULL,5,'test','32','testtesttest','','f2ccf530-21fe-42ec-a8dc-d98372db1a6a'),(27,'yesyyygafjeu','2023-01-01 21:51:40',NULL,5,'fhaej','37284','yesyy','ygafjeu','e49b8933-4082-4954-a4dd-ba9a77512d9a'),(28,'yesyyygafjeu','2023-01-01 21:53:35',NULL,5,'fhaej','37284','yesyy','ygafjeu','439e4744-45ea-47a9-bd04-a09e9a07f8e7'),(29,'testtest','2023-01-01 22:10:08',NULL,1,'iuhkjacb@jhed','83926','test','test','a3836fe9-5d30-4e23-b18a-d2d6abbddd06'),(30,'testtest','2023-01-01 22:36:33',NULL,1,'iuhkjacb@jhed','83926','test','test','c431f137-b9fb-47df-8c6a-af536a2798c3'),(31,'DeshanKavindu','2023-01-04 20:12:26',NULL,9,'ewklf','2103920','Deshan','Kavindu','55982b65-f590-413e-9ec9-4fa5da102263'),(32,'DeshanKavindu','2023-01-04 20:58:46',NULL,9,'ewklf','2103920','Deshan','Kavindu','1101f282-be74-4ab6-ba91-3e3a90adee64'),(33,'DeshanKavindu','2023-01-04 20:59:58',NULL,9,'ewklf','2103920','Deshan','Kavindu','ca0fc921-0c4b-4ffa-8ee7-3b02b9c129d5'),(34,'DeshanKavindu','2023-01-04 21:02:56',NULL,9,'ewklf','2103920','Deshan','Kavindu','323abeff-7aa2-4a9a-80b0-3117481f791b'),(35,'DeshanKavindu','2023-01-04 21:04:08',NULL,9,'ewklf','2103920','Deshan','Kavindu','d7cda371-37a5-472a-ac27-9534f08348d5'),(36,'testtest','2023-01-04 21:16:43',NULL,8,'jdsfn','2376','test','test','e0639367-fb2f-49f6-bbc3-8ac050069fdf'),(37,'testtest','2023-01-04 21:20:43',NULL,8,'jdsfn','2376','test','test','e1346522-9576-464d-921a-98ec8e8cbbb7'),(38,'KavinduDeshan','2023-01-04 21:21:35',NULL,8,'hdjask','9327','Kavindu','Deshan','469003f9-7ef0-4622-a6df-dd28077b641e'),(39,'testtest','2023-01-04 22:10:44',NULL,9,'jksnd','983','test','test','4fdba3a2-a347-4c64-b365-66b3ef13ce90');
/*!40000 ALTER TABLE `tblreservations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblseats`
--

DROP TABLE IF EXISTS `tblseats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblseats` (
  `SeatId` int NOT NULL AUTO_INCREMENT,
  `SeatIndex` int DEFAULT NULL,
  PRIMARY KEY (`SeatId`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblseats`
--

LOCK TABLES `tblseats` WRITE;
/*!40000 ALTER TABLE `tblseats` DISABLE KEYS */;
INSERT INTO `tblseats` VALUES (1,1),(2,2),(3,3),(4,8),(5,9),(6,24),(7,25),(8,26),(9,62),(10,6),(11,7),(12,91),(13,71);
/*!40000 ALTER TABLE `tblseats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblusers`
--

DROP TABLE IF EXISTS `tblusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblusers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Username` varchar(40) DEFAULT NULL,
  `Password` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblusers`
--

LOCK TABLES `tblusers` WRITE;
/*!40000 ALTER TABLE `tblusers` DISABLE KEYS */;
INSERT INTO `tblusers` VALUES (1,'Admin','12QWaszx'),(2,'Admin1','12QWaszx');
/*!40000 ALTER TABLE `tblusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-04 23:05:50

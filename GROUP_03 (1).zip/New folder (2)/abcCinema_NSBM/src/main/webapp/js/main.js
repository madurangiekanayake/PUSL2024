function registerUser(){
	var formData = JSON.stringify($("#registerForm").serializeArray());
	console.log(formData);
	
	var postStr = "";
	const jsonObj = JSON.parse(formData);
	for(var i = 0; i < jsonObj.length; i++){
		postStr = postStr + '"' + jsonObj[i].name + '":"' + jsonObj[i].value + '"';
		if(i != jsonObj.length){
			postStr = postStr + ","
		}
		
	}
	var str = postStr.substring(0,postStr.length-1);
	console.log(str);
	const postObj = '{' +str +'}';
	console.log(postObj);
	const jsonForm = JSON.parse(postObj);
	
	$.ajax({
           url: "/abcCinema_NSBM/Register",
           dataType: "json",
           type: "POST",
           async: true,
           data:jsonForm,
           success: function () {
			alert("Registration successful.")
			document.getElementById("registerForm").reset();
                 
           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
              
              
           }
       });
}

function logIn(){
	var formData = JSON.stringify($("#logInForm").serializeArray());
	console.log(formData);
	
	var postStr = "";
	const jsonObj = JSON.parse(formData);
	for(var i = 0; i < jsonObj.length; i++){
		postStr = postStr + '"' + jsonObj[i].name + '":"' + jsonObj[i].value + '"';
		if(i != jsonObj.length){
			postStr = postStr + ","
		}
		
	}
	var str = postStr.substring(0,postStr.length-1);
	console.log(str);
	const postObj = '{' +str +'}';
	console.log(postObj);
	const jsonForm = JSON.parse(postObj);
	
	$.ajax({
           url: "/abcCinema_NSBM/login",
           dataType: "json",
           type: "POST",
           async: true,
           data:jsonForm,
           success: function () {
			//alert("Login successful.")
                 getCurrentUser();
document.getElementById("logInForm").reset();

           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
              
              
           }
       });
	
}
function logOut(){
	$.ajax({
           url: "/abcCinema_NSBM/logout",
           dataType: "json",
           type: "GET",
           async: true,
     
           success: function () {
					
				getCurrentUser();
			
                 
           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
				console.log(msg);
              
              
           }
       });
}
window.onload = function(){
	getCurrentUser();
}

var user;

function ChangeForm(){
	
getCurrentUser();

$.ajax({
           url: "/abcCinema_NSBM/getUser",
           dataType: "json",
           type: "GET",
           async: true,
     
           success: function (data) {
					console.log("tets");
					user = data;
					if(data.Username != "Default"){
						if(data.Username != "Default"){
		document.getElementById("SeatsForm").innerHTML = "<p>press -place order to book selected seats. Account details will be used for the reservation details</p>"
	}
					}
					
				

           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
				console.log(msg);
              
              
           }
       });
	
	
	
}

function getCurrentUser(){

		$.ajax({
           url: "/abcCinema_NSBM/getUser",
           dataType: "json",
           type: "GET",
           async: true,
     
           success: function (data) {
					console.log("tets");
					user = data;
					if(data.Username != "Default"){
						console.log(data.Username);
						document.getElementById("loginToggle").innerHTML = '<a class="nav-link" onclick="logOut()" >'+data.Username+' -Logout</a>';
					}else{
						console.log(data + "nul");
						document.getElementById("loginToggle").innerHTML = '<a class="nav-link" href="/abcCinema_NSBM/views/Login.jsp">Login</a>';
					}
					
				

           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
				console.log(msg);
              
              
           }
       });


}



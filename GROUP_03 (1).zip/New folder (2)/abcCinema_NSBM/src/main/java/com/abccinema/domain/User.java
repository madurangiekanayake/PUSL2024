package com.abccinema.domain;

public class User {
	private int UserId;
	private String Username;
	
	public int getUserId() {
		return UserId;
	}

	public void setUserId(int userId) {
		UserId = userId;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public User() {
		super();
	}

	public User(int userId, String username, String address, String password, String tp, String email) {
		super();
		UserId = userId;
		Username = username;
		Address = address;
		Password = password;
		Tp = tp;
		Email = email;
	}

	public User(String username) {
		super();
		Username = username;
	}

	public User(int userId, String username) {
		super();
		UserId = userId;
		Username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getTp() {
		return Tp;
	}

	public void setTp(String tp) {
		Tp = tp;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String Address;
	
	private String Password;
	private String Tp;
	private String Email;
	
}

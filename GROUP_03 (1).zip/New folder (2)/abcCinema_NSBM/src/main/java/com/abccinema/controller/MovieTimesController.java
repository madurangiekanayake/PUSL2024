package com.abccinema.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.abccinema.services.MovieTimeService;
import com.google.gson.Gson;

/**
 * Servlet implementation class MovieTimesController
 */
@WebServlet("/MovieTimesController")
public class MovieTimesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Gson gson;
	private MovieTimeService _movieTimeService;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MovieTimesController() {
        super();
        gson = new Gson();
        _movieTimeService = new MovieTimeService();
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String usrJson = this.gson.toJson(_movieTimeService.GetConfiguredDates());
		
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
	
		out.print(usrJson);
		out.flush();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.abccinema.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.abccinema.models.Movie;



public class MovieService {
	private static String INSERT_MOVIE = "INSERT INTO tblmovies" + "(MovieTitle, Director,Description,ImagePath)" + "Values(?, ?, ?, ?);";
	private static String SELECT_ALL_MOVIES = "Select * from tblmovies";
	
	private DbConnection db= new DbConnection();
	private Connection _connection;
	
	public MovieService() {
		this._connection = db.getConnection();
	}
	
	public void insertMovie(Movie movie) {
		System.out.println(INSERT_MOVIE);
		try(
				PreparedStatement preparedStatement = _connection.prepareStatement(INSERT_MOVIE)){
			preparedStatement.setString(1, movie.getMovieTitle());
			preparedStatement.setString(2, movie.getDirector());
			preparedStatement.setString(3, movie.getDescription());
			preparedStatement.setString(4, movie.getImagePath());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		}catch(SQLException e) {
			db.printSQLException(e);
		}
	}
	
	public List<Movie> GetAllMovies(){
		List<Movie> movies = new ArrayList<>();
		
		try(PreparedStatement ps = _connection.prepareStatement(SELECT_ALL_MOVIES) ){
			System.out.println(ps);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				movies.add(new Movie(rs.getInt("id"), rs.getString("MovieTitle"), rs.getString("Description"), rs.getString("ImagePath"), rs.getString("Director") ));
			}

			
		}catch(SQLException e){
		     db.printSQLException(e);
		}
		
		return movies;
		
	}
	
	
}

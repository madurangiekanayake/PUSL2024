package com.abccinema.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.abccinema.domain.dtoReservedSeats;
import com.abccinema.domain.dtoScheduledMovies;
import com.abccinema.models.Movie;

public class MovieTimeService {
	
	private static String GET_MOVIES_BY_DATE = "select tblmovies.* , tblmovietimes.* from tblmovietimes join tblmovies on tblmovietimes.tblmovieId = tblmovies.id where tblmovietimes.DateAndTime between ? and ?;";
	private static String GET_CONFIGURED_DATES = "Select tblmovietimes.DateAndTime from tblmovietimes where DateAndTime > ?;";
	private static String GET_RESERVED_SEATS_BY_TIMEID ="Select tblreservations.* , tblseats.* ,tblmovietimes.* from tblreservations join tblmovietimes on tblmovietimes.MovieTimeId = tblreservations.tblmovietimeId join tbl_seat_reservations On tblreservations.ReservationId = tbl_seat_reservations.ReservationId join tblseats On tblseats.SeatId = tbl_seat_reservations.SeatId where tblreservations.tblmovietimeId = ?;";
	private static String GET_RESERVATIONS_BYLOGGED_USER ="Select tblreservations.* ,tblmovietimes.*, tblmovies.* from tblreservations join tblmovietimes on tblmovietimes.MovieTimeId = tblreservations.tblmovietimeId  join tblmovies on tblmovies.id = tblmovietimes.tblmovieId where tblreservations.tblusersId = ?;";
	private DbConnection db= new DbConnection();
	private Connection _connection;
	public MovieTimeService() {
		this._connection = db.getConnection();
	}
	
	public List<dtoScheduledMovies> getScheduledMovies(String date)
	{
		String str = date + " 00:00:00";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		LocalDateTime SelectedDate = LocalDateTime.parse(str, formatter);
		LocalDateTime RangeEnds = SelectedDate.plusDays(1);
		
		List<dtoScheduledMovies> movies = new ArrayList<>();
		try(PreparedStatement ps = _connection.prepareStatement(GET_MOVIES_BY_DATE)){
			ps.setString(1, SelectedDate.toString());
			ps.setString(2, RangeEnds.toString());
			System.out.println(ps);
			ResultSet rs = ps.executeQuery();
			System.out.println(rs);
			while(rs.next()) {
				String DateTimeStr = rs.getString("DateAndTime");
				
				LocalDateTime dateTime = LocalDateTime.parse(DateTimeStr, formatter);
				movies.add(new dtoScheduledMovies(rs.getInt("id"), rs.getString("MovieTitle"),rs.getInt("MovieTimeId"), rs.getString("Description"), rs.getString("Director") ,rs.getString("DateAndTime"), rs.getString("ImagePath") ));
			}
		}catch(SQLException e) {
			db.printSQLException(e);
		}
		
		return movies;
	}
	
	public List<String> GetConfiguredDates(){
		List<String> dates = new ArrayList<>();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate currentDate = LocalDate.now();
		try(PreparedStatement ps = _connection.prepareStatement(GET_CONFIGURED_DATES)){
			ps.setString(1, currentDate.toString());
			
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
				String Time = rs.getString("DateAndTime");
				LocalDateTime dateTime = LocalDateTime.parse(Time, formatter1);
				String DateOnly = dateTime.toLocalDate().toString();
				if(!dates.contains(DateOnly)) {
					dates.add(DateOnly);
				}
				
			}
			
		}catch(SQLException e) {
			db.printSQLException(e);
		}
		
		return dates;
		
	}
	
	public List<dtoReservedSeats> getSeatsReserved(int id){
		List<dtoReservedSeats> seats = new ArrayList();
		try(PreparedStatement ps = _connection.prepareStatement(GET_RESERVED_SEATS_BY_TIMEID)){
			ps.setString(1, Integer.toString(id));
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				seats.add(new dtoReservedSeats(rs.getInt("SeatId"), rs.getInt("SeatIndex")));
			}
			
		}catch(SQLException e) {
			db.printSQLException(e);
		}
		
		
		return seats;
	}
	public List<Movie> getReservationsByUserId(int id){
		List<Movie> movies = new ArrayList();
		try(PreparedStatement ps = _connection.prepareStatement(GET_RESERVATIONS_BYLOGGED_USER)){
			ps.setString(1, Integer.toString(id));
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				movies.add(new Movie(rs.getInt("ReservationId"), rs.getString("MovieTitle"), rs.getString("ImagePath"), rs.getInt("reservationId"), rs.getString("DateAndTime")));
			}
			
		}catch(SQLException e) {
			db.printSQLException(e);
		}
		
		
		return movies;
	}

}

var PosList = [];
var seatIndexs = [];

function mapImageIndex(){
	var mapCoords = document.getElementsByTagName("map")[0];
	var imgMapStr = '';
	for(var c = 0; c<100; c++){
		imgMapStr = imgMapStr + '<button style=" background: transparent; border: none !important; font-size:0;"  onclick="AddSeatToList('+c+', true)"><area shape="circle" coords="'+PosList[c].ValueX+','+ PosList[c].ValueY+',10"  alt="Cup of coffee" ></button >';
	}
	mapCoords.innerHTML = imgMapStr;
}


function placeBookedSeats(){
	disallowedSeats.forEach(function setSeat(index){
		console.log(index);
		AddSeatToList(index, false);
	})
}


function createPositionList(){
	var x = 184;
	var y = 22; 
	var index = 1;
	
	for(var i = 0; i <5; i++){
		
		for(var a = 0; a <20; a++){
			
			var singleObj = {}
    		singleObj['ValueX'] = x;
    		singleObj['ValueY'] = y;
    		PosList.push(singleObj);
			x = x+33;
			index++;
		};
		y = y+24;
		x = 184;

	};
	PosList.forEach(function(data){
		//console.log(data.ValueX)
	})
}



$(document).ready(function(){
	
	createPositionList();
	mapImageIndex();
	placeBookedSeats();
})

var disallowedSeats =[];

function disallowedSeatIndex(data){
	for(var i = 0; i < data.length; i++){
		console.log(data[i])
		disallowedSeats.push(data[i].seadIndex);
	};
}
var timeIDReceived;
function getBookedSeats(timeId){
	timeIDReceived = timeId;
	$.ajax({
           url: "/abcCinema_NSBM/getReservedSeats?timeId="+ timeId,
           dataType: "json",
           type: "GET",
           async: true,
           
           success: function (data) {
                 disallowedSeatIndex(data);
				 placeBookedSeats();
				 
           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
              
              
           }
       });
}

function submiTfORM(){
	var formData = JSON.stringify($("#Form").serializeArray());
	console.log(formData);
	var postStr = "";
	const jsonObj = JSON.parse(formData);
	for(var i = 0; i < jsonObj.length; i++){
		postStr = postStr + '"' + jsonObj[i].name + '":"' + jsonObj[i].value + '", ';
	}
	$.ajax({
           url: "/abcCinema_NSBM/getUser",
           dataType: "json",
           type: "GET",
           async: false,
     
           success: function (data) {
					console.log("tets");
					user = data;
					if(data.Username != "Default"){
						postStr = postStr + '"UserId":"'+ data.UserId+'", ';
					}
					
				

           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
				console.log(msg);
              
              
           }
       });
	const postObj = '{' +postStr +'"SeatsReserved" : '+'"['+ seatIndexs+ ']", "TimeId":"'+timeIDReceived+'"}';
	console.log(postObj);
	const jsonForm = JSON.parse(postObj);
	
	
	$.ajax({
           url: "/abcCinema_NSBM/CreateReservation",
           dataType: "json",
           type: "POST",
           async: true,
           data:jsonForm,
           success: function (data) {
                 
           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
              
              
           }
       });
	
	
}

function AddSeatToList(c,isRemoveble){
	
	i = PosList[c].ValueX
	x = PosList[c].ValueY
	console.log(i,x);
	x = x-5;
	i = i - 7;
	var tickList = document.getElementById('seatMap');
	var str = tickList.innerHTML;
	if(isRemoveble){
		
		var newStr = str + '<svg onclick="removeSelectedSeat('+c+')" id="index'+i+'~'+x+'" style="color:7FFF00; position: absolute;top: '+x+'px;left: '+i+'px;" xmlns="http://www.w3.org/2000/svg" width="25" height="19" fill="currentColor" class="bi bi-bookmark-check-fill" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M2 15.5V2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.74.439L8 13.069l-5.26 2.87A.5.5 0 0 1 2 15.5zm8.854-9.646a.5.5 0 0 0-.708-.708L7.5 7.793 6.354 6.646a.5.5 0 1 0-.708.708l1.5 1.5a.5.5 0 0 0 .708 0l3-3z"/></svg>';
		seatIndexs.push(c);
	}else{
		var newStr = str + '<svg xmlns="http://www.w3.org/2000/svg" width="25" style="color:FF4500; position: absolute;top: '+x+'px;left: '+i+'px;" height="19" fill="currentColor" class="bi bi-lock-fill" viewBox="0 0 16 16"><path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/></svg>';
	}
	
	
	tickList.innerHTML = newStr;
}

function removeSelectedSeat(c){
	i = PosList[c].ValueX
	x = PosList[c].ValueY
	x = x-5;
	i = i - 7;
	var imgId = 'index' + i + '~' + x;
	var image_x = document.getElementById(imgId);
	image_x.parentNode.removeChild(image_x);
	seatIndexs.splice(seatIndexs.indexOf(c), 1);
}
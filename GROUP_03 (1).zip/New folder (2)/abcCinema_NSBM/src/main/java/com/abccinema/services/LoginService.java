package com.abccinema.services;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.abccinema.domain.User;
import com.abccinema.domain.dtoReservedSeats;

public class LoginService {
	
	public static String GET_USER_BY_USERNAME = "SELECT * FROM test1.tblusers where Username = ?;";
	
	public static String REGISTER_USER = "INSERT INTO test1.tblusers (`Username`,`Password`, `Address`, `Email`, `Tp`, `isActive`) VALUES (?, ?, ?, ?, ?, ?);";
	private HashingService _hashingService;
	private Connection _connection;
	private DbConnection db= new DbConnection();
	
	
	public LoginService() {
		this._hashingService = new HashingService();
		this._connection = db.getConnection();
	}
	
	 public User login(HttpServletRequest request) throws IOException {
		 User user = new User();
		 String Username = request.getParameter("username");
		 String Password = request.getParameter("password");
		 
		 
		 
		 
			String PWHash = "";
			try {
				PWHash = this._hashingService.HashText(Password);
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			System.out.println(PWHash);
			try(PreparedStatement ps = _connection.prepareStatement(GET_USER_BY_USERNAME)){
				ps.setString(1, Username);
				ResultSet rs = ps.executeQuery();
				while(rs.next()) {
					System.out.println(rs.getString("Password"));
					System.out.println(rs.getString("Username"));
					
					if(rs.getString("Password").equals(PWHash)) {
						System.out.println("if");
						User matchUser = new User(Integer.parseInt(rs.getString("id")), rs.getString("Username"));
						return matchUser;
						
						
					}
				
				}
				
			}catch(SQLException e) {
				db.printSQLException(e);
			}
			
			
			System.out.println(user.getUsername());
			
			
			return user;
			
			
			
		 
	 }
	 
	 public void registerUser(User user) throws NoSuchAlgorithmException {
		 try(
					PreparedStatement preparedStatement = _connection.prepareStatement(REGISTER_USER)){
				preparedStatement.setString(1, user.getUsername());
				preparedStatement.setString(2, this._hashingService.HashText(user.getPassword()));
				preparedStatement.setString(3, user.getAddress());
				preparedStatement.setString(4, user.getEmail());
				preparedStatement.setString(5, user.getTp());
				preparedStatement.setString(6, "1");
				System.out.println(preparedStatement);
				preparedStatement.executeUpdate();
			}catch(SQLException e) {
				db.printSQLException(e);
			}
	 }

}

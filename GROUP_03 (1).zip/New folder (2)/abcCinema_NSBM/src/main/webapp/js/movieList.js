function setMovieList(data){
	var list = document.getElementById('movieList');
	
	console.log( data.length );
	var innerStr = "";
	for(var i =0; i < data.length; i++){
		var newCard = `<div class="col-6 mb-3"><button onclick="location.href='/abcCinema_NSBM/SeatIndex?timeId=`+data[i].ShowTimeId+`'" style="background: transparent; border: none !important; outline:none;"><div class="card mb-3" style="max-width: 540px;">
  <div class="row g-0">
    <div class="col-md-4">
      <img src="`+data[i].ImagePath +`.jpeg" class="img-fluid rounded-start" alt="...">
    </div>
    <div class="col-md-8">
      <div class="card-body">
        <h5 class="card-title">` + data[i].Movie+`</h5>
        <p class="card-text">`+data[i].MovieDescription+`</p>
        <p class="card-text"><small class="text-muted">Directed by: `+data[i].Director+`</small></p>
      </div>
    </div>
  </div>
</div></button></div>`;
		innerStr = innerStr + newCard;
		
	}
	list.innerHTML = innerStr;
};

function setCarouselImages(data){
	var list = document.getElementById('carouselImages');
	
	console.log( data.length );
	var innerStr = "";
	for(var i =0; i < data.length; i++){
		var newCard = `<div class="carousel-item active">
      <img src="`+data[i].ImagePath+`1.jpeg" class="d-block w-100" width="1000" height="520" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>`+data[i].Movie+`</h5>
        <p>`+data[i].Director+`.</p>
      </div>
    </div>`
	innerStr = innerStr + newCard;
	}
	list.innerHTML = innerStr;
}

$(document).ready(function() {
    console.log( "ready!" );
    var today = new Date();
	var dd = String(today.getDate()).padStart(2, '0');
	var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
	var yyyy = today.getFullYear();

	today = yyyy + '-' + mm + '-' + dd;
	console.log(today);
    $.ajax({
           url: "MoviesByDatesController?dateSelected="+ today,
           dataType: "json",
           type: "GET",
           async: true,
           
           success: function (data) {
                   setMovieList(data);
				   setCarouselImages(data);
           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
              
              
           }
       });
});
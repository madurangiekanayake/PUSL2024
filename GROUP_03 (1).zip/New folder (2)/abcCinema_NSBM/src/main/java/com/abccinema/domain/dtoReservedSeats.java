package com.abccinema.domain;

public class dtoReservedSeats {
	public int seatID;
	public int seadIndex;
	public int getSeatID() {
		return seatID;
	}
	public void setSeatID(int seatID) {
		this.seatID = seatID;
	}
	public int getSeadIndex() {
		return seadIndex;
	}
	public void setSeadIndex(int seadIndex) {
		this.seadIndex = seadIndex;
	}
	public dtoReservedSeats(int seatID, int seadIndex) {
		super();
		this.seatID = seatID;
		this.seadIndex = seadIndex;
	}

	
}

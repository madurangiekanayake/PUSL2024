package com.abccinema.services;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	private String jdbcURL = "jdbc:mysql://localhost:3306/test1?allowPublicKeyRetrieval=true&useSSL=false";
	private String username = "root";
	private String password = "12QWaszx";
	private String driver = "com.mysql.jdbc.Driver";
	
	public DbConnection() {
		
	}
	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName(driver);
		    conn = DriverManager.getConnection(jdbcURL, username, password);
		    
		}catch(SQLException e){
			 e.printStackTrace();
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return conn;
	}
	
	public void printSQLException(SQLException ex) {
		// TODO Auto-generated method stub
		for (Throwable e :ex) {
			if(e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState:" + ((SQLException) e).getSQLState());
				System.err.println("Error-code:" + ((SQLException) e).getErrorCode());
				System.err.println("Message:" + e.getMessage());
				Throwable t = e.getCause();
				while(t != null) {
					System.out.println("cause: " +t);
				}
				}
		}
}}

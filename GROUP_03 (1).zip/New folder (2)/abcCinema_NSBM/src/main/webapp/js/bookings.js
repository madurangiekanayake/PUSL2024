window.onload = function getBookings(){
	$.ajax({
           url: "/abcCinema_NSBM/getUser",
           dataType: "json",
           type: "GET",
           async: true,
     
           success: function (data) {
					console.log("tets");
					user = data;
					if(data.Username != "Default"){
						console.log(data.Username);
						getList(data.UserId);
						document.getElementById("loginToggle").innerHTML = '<a class="nav-link" onclick="logOut()" >'+data.Username+' -Logout</a>';
					}else{
						console.log(data + "nul");
						document.getElementById("loginToggle").innerHTML = '<a class="nav-link" href="/abcCinema_NSBM/views/Login.jsp">Login</a>';
						
					}
					
				

           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
				console.log(msg);
              
              
           }
       });

}

function getList(userid){
	$.ajax({
           url: "/abcCinema_NSBM/GetMoviesByUser?userID="+ userid,
           dataType: "json",
           type: "GET",
           async: true,
           
           success: function (data) {
					
                   ShowList(data);
           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
              
              
           }
       });
	
}

function postReview(){
	var review = "";
	review = document.getElementById("review").value;
	$.ajax({
           url: "/abcCinema_NSBM/Review?reservationId="+ reservation + "&review=" + review,
           dataType: "json",
           type: "GET",
           async: true,
           
           success: function () {
					alert("Review has been added.");
                   
           },
           error: function (xhr, exception, thrownError) {
               var msg = "";
               if (xhr.status === 0) {
                   msg = "Not connect.\n Verify Network.";
               } else if (xhr.status == 404) {
                   msg = "Requested page not found. [404]";
               } else if (xhr.status == 500) {
                   msg = "Internal Server Error [500].";
               } else if (exception === "parsererror") {
                   msg = "Requested JSON parse failed.";
               } else if (exception === "timeout") {
                   msg = "Time out error.";
               } else if (exception === "abort") {
                   msg = "Ajax request aborted.";
               } else {
                   msg = "Error:" + xhr.status + " " + xhr.responseText;
               }
              
              
           }
       });
	
}

var reservation = 0;

function setReservationId(i){
	reservation = i;
	console.log(reservation);
}

function ShowList(data){
   var str = "";

	for(var i = 0; i < data.length; i++){
		str = str + ` <button type="button"  data-bs-toggle="modal" data-bs-target="#exampleModal" onclick="setReservationId(`+data[i].reservationId+`)" style="background: transparent; border: none !important; outline:none;"><li class="list-group-item d-flex justify-content-between align-items-center">
          ` + data[i].MovieTitle+` Reservation Date:- `+data[i].reservationDate+`
          <div class="image-parent">
              <img src="`+data[i].ImagePath+`.jpeg" height="200px" width="120px" class="img-fluid" alt="quixote">
          </div>
        </li></button>`
	}
	
	document.getElementById("bookingList").innerHTML = str;



}
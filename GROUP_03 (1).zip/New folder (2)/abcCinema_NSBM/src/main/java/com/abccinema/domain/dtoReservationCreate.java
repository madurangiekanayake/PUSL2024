package com.abccinema.domain;

import java.util.List;

public class dtoReservationCreate {
		private String FirstName;
		private String LastName;
		private String Address;
		private String Email;
		private String MobileNo;
		private String Comments;
		private List<Integer> SeatsReserved;
}

package com.abccinema.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.UUID;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

public class ReservationService {
	private static String CREATE_RESERVATION = "INSERT INTO tblreservations" + "(ReservedPerson, CurrentDate,tblmovieId,tblmovietimeId, Address,MobileNo, FirstName, LastName, Guid, tblusersId )" + "Values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
	private static String SELECT_ALL_MOVIES = "Select * from tblmovies";
	private static String GET_RESERVATION_BY_GUID = "SELECT * FROM test1.tblreservations where tblreservations.Guid = ?;";
	private static String BIND_SEATS= "INSERT INTO tbl_seat_reservations(SeatId, ReservationId) Values(?,?);";
	private static String GET_SEAT_INDEX= "SELECT * FROM test1.tblseats where tblseats.SeatIndex = ?;";
	private static String CREATE_SEAT= "INSERT INTO tblseats(SeatIndex) Values(?);";
	private static String CREATE_REVIEW = "INSERT INTO test1.tblreviews (`Review`, `tblreservationId`, `Stars`) VALUES (?, ?, ?)";
	
	
	private DbConnection db= new DbConnection();
	private Connection _connection;
	
	public ReservationService() {
		this._connection = db.getConnection();
	}
	private String getSeatByIndex(String index) {
		int id = 0;
		try(
				PreparedStatement ps = _connection.prepareStatement(GET_SEAT_INDEX)){
				ps.setString(1, index);
				ResultSet rs= ps.executeQuery();
				
				while(rs.next()) {
					id = rs.getInt("SeatId");
					
				}
	
		}
		catch(SQLException e) {
			db.printSQLException(e);
		}
		
		return Integer.toString(id);
	}
	
	private String CreateSeat(String index) {
		String id = getSeatByIndex(index);
		System.out.println("Writing" + id + index);
		if(id.equals("0")) {
			System.out.println("iffWriting");
			try(
					PreparedStatement ps = _connection.prepareStatement(CREATE_SEAT)){
					ps.setString(1, index);
					ps.executeUpdate();
					
			}
			catch(SQLException e) {
				db.printSQLException(e);
			}
		}else {
			
		}
		id = getSeatByIndex(index);
		System.out.println("Writing" + id + index);
		return id;
	}

	public void reserveSeats(HttpServletRequest request) {
		String uuid = UUID.randomUUID().toString();
		String savedReservationId = new String();
		// declaring the string
        String str = request.getParameter("SeatsReserved").replace("[", "").replace("]", "").toString();
       
        System.out.println(str);
 
      
        List<Integer> arr  = new ArrayList();
        
        int[] numbers = Arrays.stream(str.split(",")).mapToInt(Integer::parseInt).toArray(); 
 
      
     
        
		try(
				PreparedStatement ps = _connection.prepareStatement(CREATE_RESERVATION)){
			ps.setString(1, request.getParameter("FirstName") + request.getParameter("LastName"));
			ps.setString(2, LocalDateTime.now().toString());
			ps.setString(3, null);
			ps.setString(4, request.getParameter("TimeId"));
			ps.setString(5, request.getParameter("Address"));
			ps.setString(6, request.getParameter("MobileNo"));
			ps.setString(7, request.getParameter("FirstName"));
			ps.setString(8, request.getParameter("LastName"));
			ps.setString(9, uuid);
			ps.setString(10, request.getParameter("UserId"));
			ps.executeUpdate();
			
		}
		catch(SQLException e) {
			db.printSQLException(e);
		}
		try(
				PreparedStatement ps = _connection.prepareStatement(GET_RESERVATION_BY_GUID)){
			ps.setString(1,uuid );
			ResultSet rs = ps.executeQuery();
			while(rs.next()) {
				savedReservationId = rs.getString("ReservationId");
				System.out.println(savedReservationId);
			}
			
			
		}
		catch(SQLException e) {
			db.printSQLException(e);
		}
		if(savedReservationId.length() > 0) {
			try(
					PreparedStatement ps = _connection.prepareStatement(BIND_SEATS)){
				for(var i = 0; i < numbers.length; i++) {
					int a = numbers[i];
					
					String number = CreateSeat(Integer.toString(a));
					System.out.println(number);
					
					String reservation = savedReservationId;
					System.out.println(reservation);
					ps.setString(1, number);
					ps.setString(2, reservation);
					ps.executeUpdate();
					
					
				}
				
				
			}
			catch(SQLException e) {
				db.printSQLException(e);
			}
		}
		
		
		
		
	}
	
	public void createReview(int ReservationId, String Review) {
		try(
				PreparedStatement ps = _connection.prepareStatement(this.CREATE_REVIEW)){
			ps.setString(1, Review);
				ps.setString(2, Integer.toString(ReservationId));
				ps.setString(3, "0");
				ps.executeUpdate();
				
		}
		catch(SQLException e) {
			db.printSQLException(e);
		}
	}
}
